﻿using System;
using System.Data;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Xml;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace MiniSGBD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // ----------------------- BOTÃO CONECTAR -----------------------
        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDatabase.Text))
            {
                MessageBox.Show("Digite o nome da base.");
                return;
            }

            DbHelper.SetDatabase(txtDatabase.Text);
            MessageBox.Show("Conectado com sucesso!");
        }

        // ----------------------- EXECUTAR QUERY -----------------------
        private void btnRunQuery_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = DbHelper.ExecuteQuery(txtQuery.Text);
                dgvQuery.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao executar query:\n{ex.Message}");
            }
        }

        // ----------------------- SALVAR XML -----------------------
        private void btnSaveXml_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtXmlName.Text))
                {
                    MessageBox.Show("Digite o nome do XML.");
                    return;
                }

                // Escolher arquivo XML
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "XML Files|*.xml";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string xmlContent = File.ReadAllText(ofd.FileName);
                    DbHelper.SaveXml(txtXmlName.Text, xmlContent);
                    MessageBox.Show("XML salvo na base!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar XML:\n{ex.Message}");
            }
        }

        // ----------------------- EXPORTAR XML -----------------------
        private void btnExportXml_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtTableExportXml.Text))
                {
                    MessageBox.Show("Digite o nome da tabela.");
                    return;
                }

                string xml = DbHelper.ExportXmlFromTable(txtTableExportXml.Text);
                if (string.IsNullOrWhiteSpace(xml))
                {
                    MessageBox.Show("Nenhum dado retornado.");
                    return;
                }

                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "XML Files|*.xml";
                sfd.FileName = "exportado.xml";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(sfd.FileName, xml);
                    MessageBox.Show("XML exportado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao exportar XML:\n{ex.Message}");
            }
        }

        // ----------------------- MOSTRAR JSON -----------------------
        private void btnShowJson_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtJson.Text))
                {
                    MessageBox.Show("Digite o JSON.");
                    return;
                }

                DataTable dt = JsonConvert.DeserializeObject<DataTable>(txtJson.Text);
                dgvJsonPreview.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar JSON:\n{ex.Message}");
            }
        }

        // ----------------------- SALVAR JSON -----------------------
        private void btnSaveJson_Click(object sender, EventArgs e)
        {
            try
            {
                DbHelper.SaveJson(txtJson.Text);
                MessageBox.Show("JSON salvo com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar JSON:\n{ex.Message}");
            }
        }

        // ----------------------- CRUD: CREATE -----------------------
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                string sql =
                    $"INSERT INTO {txtTableCrud.Text} ({txtField.Text}) VALUES ('{txtValue.Text}');";

                DbHelper.ExecuteNonQuery(sql);
                MessageBox.Show("Registro criado!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao inserir:\n{ex.Message}");
            }
        }

        // ----------------------- CRUD: READ -----------------------
        private void btnRead_Click(object sender, EventArgs e)
        {
            try
            {
                string sql =
                    $"SELECT * FROM {txtTableCrud.Text} WHERE id = {txtCrudId.Text};";

                dgvQuery.DataSource = DbHelper.ExecuteQuery(sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao consultar:\n{ex.Message}");
            }
        }

        // ----------------------- CRUD: UPDATE -----------------------
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string sql =
                    $"UPDATE {txtTableCrud.Text} SET {txtField.Text} = '{txtValue.Text}' WHERE id = {txtCrudId.Text};";

                DbHelper.ExecuteNonQuery(sql);
                MessageBox.Show("Registro atualizado!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao atualizar:\n{ex.Message}");
            }
        }

        // ----------------------- CRUD: DELETE -----------------------
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string sql =
                    $"DELETE FROM {txtTableCrud.Text} WHERE id = {txtCrudId.Text};";

                DbHelper.ExecuteNonQuery(sql);
                MessageBox.Show("Registro deletado!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao deletar:\n{ex.Message}");
            }
        }


        // ----------------------- EVENTOS GERADOS AUTOMATICAMENTE -----------------------
        private void txtDatabase_TextChanged(object sender, EventArgs e) { }
        private void txtQuery_TextChanged(object sender, EventArgs e) { }
        private void dgvQueryResult_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void txtXmlName_TextChanged(object sender, EventArgs e) { }
        private void txtTableExportXml_TextChanged(object sender, EventArgs e) { }
        private void txtJson_TextChanged(object sender, EventArgs e) { }
        private void txtField_TextChanged(object sender, EventArgs e) { }
        private void txtCrudId_TextChanged(object sender, EventArgs e) { }
        private void txtTableCrud_TextChanged(object sender, EventArgs e) { }
        private void txtValue_TextChanged(object sender, EventArgs e) { }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void btnGetApi_Click(object sender, EventArgs e)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                   
                    string url = "https://jsonplaceholder.typicode.com/users";

            
                    string responseJson = await client.GetStringAsync(url);

        
                    txtJson.Text = responseJson;

                    MessageBox.Show("Dados recebidos da API REST com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro na API: {ex.Message}");
            }
        }

        private void btnLimparJson_Click(object sender, EventArgs e)
        {
            txtJson.Clear();

            dgvJsonPreview.DataSource = null;

    }
    }
}
