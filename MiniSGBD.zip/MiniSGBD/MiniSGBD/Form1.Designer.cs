﻿namespace MiniSGBD
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtDatabase = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtQuery = new System.Windows.Forms.TextBox();
            this.btnRunQuery = new System.Windows.Forms.Button();
            this.dgvQuery = new System.Windows.Forms.DataGridView();
            this.labelConexao = new System.Windows.Forms.Label();
            this.labelQuery = new System.Windows.Forms.Label();
            this.labelXML = new System.Windows.Forms.Label();
            this.btnSaveXml = new System.Windows.Forms.Button();
            this.btnExportXml = new System.Windows.Forms.Button();
            this.txtXmlName = new System.Windows.Forms.TextBox();
            this.txtTableExportXml = new System.Windows.Forms.TextBox();
            this.labelJson = new System.Windows.Forms.Label();
            this.txtJson = new System.Windows.Forms.TextBox();
            this.btnShowJson = new System.Windows.Forms.Button();
            this.btnSaveJson = new System.Windows.Forms.Button();
            this.dgvJsonPreview = new System.Windows.Forms.DataGridView();
            this.labelCrud = new System.Windows.Forms.Label();
            this.txtTableCrud = new System.Windows.Forms.TextBox();
            this.txtCrudId = new System.Windows.Forms.TextBox();
            this.txtField = new System.Windows.Forms.TextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnGetApi = new System.Windows.Forms.Button();
            this.btnLimparJson = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJsonPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDatabase
            // 
            this.txtDatabase.Location = new System.Drawing.Point(15, 25);
            this.txtDatabase.Name = "txtDatabase";
            this.txtDatabase.Size = new System.Drawing.Size(120, 20);
            this.txtDatabase.TabIndex = 0;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(141, 25);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(91, 21);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Conectar";
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtQuery
            // 
            this.txtQuery.Location = new System.Drawing.Point(15, 80);
            this.txtQuery.Multiline = true;
            this.txtQuery.Name = "txtQuery";
            this.txtQuery.Size = new System.Drawing.Size(300, 50);
            this.txtQuery.TabIndex = 2;
            // 
            // btnRunQuery
            // 
            this.btnRunQuery.Location = new System.Drawing.Point(108, 136);
            this.btnRunQuery.Name = "btnRunQuery";
            this.btnRunQuery.Size = new System.Drawing.Size(90, 23);
            this.btnRunQuery.TabIndex = 3;
            this.btnRunQuery.Text = "Executar";
            this.btnRunQuery.Click += new System.EventHandler(this.btnRunQuery_Click);
            // 
            // dgvQuery
            // 
            this.dgvQuery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery.Location = new System.Drawing.Point(15, 170);
            this.dgvQuery.Name = "dgvQuery";
            this.dgvQuery.Size = new System.Drawing.Size(300, 180);
            this.dgvQuery.TabIndex = 4;
            // 
            // labelConexao
            // 
            this.labelConexao.AutoSize = true;
            this.labelConexao.Location = new System.Drawing.Point(12, 8);
            this.labelConexao.Name = "labelConexao";
            this.labelConexao.Size = new System.Drawing.Size(49, 13);
            this.labelConexao.TabIndex = 2;
            this.labelConexao.Text = "Conexão";
            // 
            // labelQuery
            // 
            this.labelQuery.AutoSize = true;
            this.labelQuery.Location = new System.Drawing.Point(12, 60);
            this.labelQuery.Name = "labelQuery";
            this.labelQuery.Size = new System.Drawing.Size(80, 13);
            this.labelQuery.TabIndex = 4;
            this.labelQuery.Text = "Executar Query";
            // 
            // labelXML
            // 
            this.labelXML.AutoSize = true;
            this.labelXML.Location = new System.Drawing.Point(380, 8);
            this.labelXML.Name = "labelXML";
            this.labelXML.Size = new System.Drawing.Size(29, 13);
            this.labelXML.TabIndex = 5;
            this.labelXML.Text = "XML";
            // 
            // btnSaveXml
            // 
            this.btnSaveXml.Location = new System.Drawing.Point(510, 25);
            this.btnSaveXml.Name = "btnSaveXml";
            this.btnSaveXml.Size = new System.Drawing.Size(100, 21);
            this.btnSaveXml.TabIndex = 7;
            this.btnSaveXml.Text = "Salvar XML";
            this.btnSaveXml.Click += new System.EventHandler(this.btnSaveXml_Click);
            // 
            // btnExportXml
            // 
            this.btnExportXml.Location = new System.Drawing.Point(510, 60);
            this.btnExportXml.Name = "btnExportXml";
            this.btnExportXml.Size = new System.Drawing.Size(100, 21);
            this.btnExportXml.TabIndex = 9;
            this.btnExportXml.Text = "Exportar XML";
            this.btnExportXml.Click += new System.EventHandler(this.btnExportXml_Click);
            // 
            // txtXmlName
            // 
            this.txtXmlName.Location = new System.Drawing.Point(380, 25);
            this.txtXmlName.Name = "txtXmlName";
            this.txtXmlName.Size = new System.Drawing.Size(120, 20);
            this.txtXmlName.TabIndex = 6;
            // 
            // txtTableExportXml
            // 
            this.txtTableExportXml.Location = new System.Drawing.Point(380, 60);
            this.txtTableExportXml.Name = "txtTableExportXml";
            this.txtTableExportXml.Size = new System.Drawing.Size(120, 20);
            this.txtTableExportXml.TabIndex = 8;
            // 
            // labelJson
            // 
            this.labelJson.AutoSize = true;
            this.labelJson.Location = new System.Drawing.Point(382, 122);
            this.labelJson.Name = "labelJson";
            this.labelJson.Size = new System.Drawing.Size(35, 13);
            this.labelJson.TabIndex = 10;
            this.labelJson.Text = "JSON";
            // 
            // txtJson
            // 
            this.txtJson.Location = new System.Drawing.Point(383, 138);
            this.txtJson.Multiline = true;
            this.txtJson.Name = "txtJson";
            this.txtJson.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtJson.Size = new System.Drawing.Size(232, 164);
            this.txtJson.TabIndex = 11;
            // 
            // btnShowJson
            // 
            this.btnShowJson.Location = new System.Drawing.Point(620, 161);
            this.btnShowJson.Name = "btnShowJson";
            this.btnShowJson.Size = new System.Drawing.Size(90, 23);
            this.btnShowJson.TabIndex = 12;
            this.btnShowJson.Text = "Mostrar JSON";
            this.btnShowJson.Click += new System.EventHandler(this.btnShowJson_Click);
            // 
            // btnSaveJson
            // 
            this.btnSaveJson.Location = new System.Drawing.Point(620, 190);
            this.btnSaveJson.Name = "btnSaveJson";
            this.btnSaveJson.Size = new System.Drawing.Size(90, 23);
            this.btnSaveJson.TabIndex = 13;
            this.btnSaveJson.Text = "Salvar JSON";
            this.btnSaveJson.Click += new System.EventHandler(this.btnSaveJson_Click);
            // 
            // dgvJsonPreview
            // 
            this.dgvJsonPreview.Location = new System.Drawing.Point(383, 317);
            this.dgvJsonPreview.Name = "dgvJsonPreview";
            this.dgvJsonPreview.Size = new System.Drawing.Size(330, 118);
            this.dgvJsonPreview.TabIndex = 14;
            // 
            // labelCrud
            // 
            this.labelCrud.AutoSize = true;
            this.labelCrud.Location = new System.Drawing.Point(87, 373);
            this.labelCrud.Name = "labelCrud";
            this.labelCrud.Size = new System.Drawing.Size(38, 13);
            this.labelCrud.TabIndex = 15;
            this.labelCrud.Text = "CRUD";
            // 
            // txtTableCrud
            // 
            this.txtTableCrud.Location = new System.Drawing.Point(90, 389);
            this.txtTableCrud.Name = "txtTableCrud";
            this.txtTableCrud.Size = new System.Drawing.Size(120, 20);
            this.txtTableCrud.TabIndex = 16;
            // 
            // txtCrudId
            // 
            this.txtCrudId.Location = new System.Drawing.Point(90, 439);
            this.txtCrudId.Name = "txtCrudId";
            this.txtCrudId.Size = new System.Drawing.Size(120, 20);
            this.txtCrudId.TabIndex = 17;
            // 
            // txtField
            // 
            this.txtField.Location = new System.Drawing.Point(90, 415);
            this.txtField.Name = "txtField";
            this.txtField.Size = new System.Drawing.Size(120, 20);
            this.txtField.TabIndex = 18;
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(90, 464);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(120, 20);
            this.txtValue.TabIndex = 19;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(225, 389);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(90, 23);
            this.btnCreate.TabIndex = 20;
            this.btnCreate.Text = "Criar";
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(225, 414);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(90, 23);
            this.btnRead.TabIndex = 21;
            this.btnRead.Text = "Ler";
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(225, 439);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 23);
            this.btnUpdate.TabIndex = 22;
            this.btnUpdate.Text = "Atualizar";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(225, 464);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 23);
            this.btnDelete.TabIndex = 23;
            this.btnDelete.Text = "Deletar";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 392);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 24;
            this.label1.Text = "Tabela:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 441);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 418);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 26;
            this.label3.Text = "Campo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 467);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Valor";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::MiniSGBD.Properties.Resources.faculdade_esamc_ins_log_g_3;
            this.pictureBox1.Image = global::MiniSGBD.Properties.Resources.faculdade_esamc_ins_log_g_3;
            this.pictureBox1.Location = new System.Drawing.Point(584, 443);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(131, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // btnGetApi
            // 
            this.btnGetApi.Location = new System.Drawing.Point(620, 219);
            this.btnGetApi.Name = "btnGetApi";
            this.btnGetApi.Size = new System.Drawing.Size(90, 23);
            this.btnGetApi.TabIndex = 30;
            this.btnGetApi.Text = "Buscar API Externa";
            this.btnGetApi.Click += new System.EventHandler(this.btnGetApi_Click);
            // 
            // btnLimparJson
            // 
            this.btnLimparJson.Location = new System.Drawing.Point(620, 248);
            this.btnLimparJson.Name = "btnLimparJson";
            this.btnLimparJson.Size = new System.Drawing.Size(90, 23);
            this.btnLimparJson.TabIndex = 31;
            this.btnLimparJson.Text = "Limpar";
            this.btnLimparJson.Click += new System.EventHandler(this.btnLimparJson_Click);
            // 
            // Form1
            // 
            this.BackgroundImage = global::MiniSGBD.Properties.Resources._6402687_3274764;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(733, 510);
            this.Controls.Add(this.btnLimparJson);
            this.Controls.Add(this.btnGetApi);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDatabase);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.labelConexao);
            this.Controls.Add(this.txtQuery);
            this.Controls.Add(this.btnRunQuery);
            this.Controls.Add(this.labelQuery);
            this.Controls.Add(this.dgvQuery);
            this.Controls.Add(this.labelXML);
            this.Controls.Add(this.txtXmlName);
            this.Controls.Add(this.btnSaveXml);
            this.Controls.Add(this.txtTableExportXml);
            this.Controls.Add(this.btnExportXml);
            this.Controls.Add(this.labelJson);
            this.Controls.Add(this.txtJson);
            this.Controls.Add(this.btnShowJson);
            this.Controls.Add(this.btnSaveJson);
            this.Controls.Add(this.dgvJsonPreview);
            this.Controls.Add(this.labelCrud);
            this.Controls.Add(this.txtTableCrud);
            this.Controls.Add(this.txtCrudId);
            this.Controls.Add(this.txtField);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Mini SGBD";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJsonPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDatabase;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtQuery;
        private System.Windows.Forms.Button btnRunQuery;
        private System.Windows.Forms.DataGridView dgvQuery;
        private System.Windows.Forms.Label labelConexao;
        private System.Windows.Forms.Label labelQuery;
        private System.Windows.Forms.Label labelXML;
        private System.Windows.Forms.Button btnSaveXml;
        private System.Windows.Forms.Button btnExportXml;
        private System.Windows.Forms.TextBox txtXmlName;
        private System.Windows.Forms.TextBox txtTableExportXml;
        private System.Windows.Forms.Label labelJson;
        private System.Windows.Forms.TextBox txtJson;
        private System.Windows.Forms.Button btnShowJson;
        private System.Windows.Forms.Button btnSaveJson;
        private System.Windows.Forms.DataGridView dgvJsonPreview;
        private System.Windows.Forms.Label labelCrud;
        private System.Windows.Forms.TextBox txtTableCrud;
        private System.Windows.Forms.TextBox txtCrudId;
        private System.Windows.Forms.TextBox txtField;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnGetApi;
        private System.Windows.Forms.Button btnLimparJson;
    }
}
