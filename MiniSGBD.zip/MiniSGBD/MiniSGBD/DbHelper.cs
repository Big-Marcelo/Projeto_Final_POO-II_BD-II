﻿using System;
using System.Data;
using Npgsql;

namespace MiniSGBD
{
    public static class DbHelper
    {
        private static string _connectionString =
            $"Host=localhost;Port=5432;Username=postgres;Password=PostgreSQL123;Database=sgbd_mini;";

        public static void SetDatabase(string dbName)
        {
            var builder = new NpgsqlConnectionStringBuilder(_connectionString);
            builder.Database = dbName;
            _connectionString = builder.ToString();
        }

        public static DataTable ExecuteQuery(string sql)
        {
            using (var conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(sql, conn))
                {
                    using (var da = new NpgsqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public static int ExecuteNonQuery(string sql)
        {
            using (var conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(sql, conn))
                {
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static void SaveXml(string name, string xmlContent)
        {
            string sql = "INSERT INTO xml_storage (xml_name, xml_content) VALUES (@name, @content::xml)";
            using (var conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("name", name);
                    cmd.Parameters.AddWithValue("content", xmlContent);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static string ExportXmlFromTable(string tableName)
        {

            string sql = $"SELECT table_to_xml('{tableName}', true, true, '');";

            using (var conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(sql, conn))
                {

                    var result = cmd.ExecuteScalar();
                    return result?.ToString() ?? "<root>Nenhum dado</root>";
                }
            }
        }

        public static void SaveJson(string json)
        {
            // O ::jsonb garante que o Postgres valide se é um JSON real
            string sql = "INSERT INTO json_storage (json_data) VALUES (@json::jsonb)";

            using (var conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("json", json);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}